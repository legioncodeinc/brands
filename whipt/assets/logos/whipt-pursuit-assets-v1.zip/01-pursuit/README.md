# WHIPT — Pursuit asset set

Editable vector SVGs, transparent PNG exports, outlined wordmark, horizontal and stacked lockups, square icons, opaque app tiles, and browser/platform icons.

- light: ink #0A0B0D + mint #3DDC97, intended for light backgrounds.
- dark: off-white #F5F6F7 + mint #3DDC97, intended for dark backgrounds.
- black / white: pure monochrome.
- The symbol, icon, wordmark and lockups have real transparent backgrounds.
- App tiles and favicons intentionally include a solid square background.
- Numbers in PNG filenames specify pixel width; icon/app-icon files are square.
- Source SVG masters are in source/. No fonts or embedded images are required.
- Keep original proportions and allow clear space around the mark.

The complete two-direction kit includes an offline visual catalog and an overview sheet.
